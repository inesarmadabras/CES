<?php

return [
    'full_size'   => 'C:\xampp\htdocs\laravel-5\public\images\full_size\full_size',
    'icon_size'   => 'C:\xampp\htdocs\laravel-5\public\images\icon_size\icon_size',
];