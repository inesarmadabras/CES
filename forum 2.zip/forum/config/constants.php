<?php

return array(
	'per_page' => 50,  // number of comments to be shown per page
);