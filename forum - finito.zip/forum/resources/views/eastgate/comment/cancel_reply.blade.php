<div class="row cancel-reply-field">
	<p class="col-md-4">
		<a href="javascript:void(0)" name="cancel_reply" class="cancel-reply btn btn-default btn-xs" title="Cancelar">&times;</a>
	</p>
</div>